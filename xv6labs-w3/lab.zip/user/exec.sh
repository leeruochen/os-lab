echo "hello world!"
ls
